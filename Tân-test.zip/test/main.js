let questionArr = [];
let questionArrIndex = 0;
getQuestionArr(10,5);

function getQuestionArr(topicID,noQ){
  let xhr = new XMLHttpRequest();
  xhr.open(
      "GET",
      `https://quizzyweb-3e807-default-rtdb.firebaseio.com/questions.json?orderBy="topic_id"&startAt="${topicID}"&endAt="${topicID}"`,
      true
  );
  xhr.onload = function() {
      if(this.status === 200) {
        let results = JSON.parse(this.responseText);
         questionArr = reduceresult(results,noQ);
      }
  }
  xhr.send();
}

function reduceresult(results,noQ){
  return Object.entries(results)
  .map(a => a.pop())
  .map((a) => ({sort: Math.random(), value: a}))
  .sort((a, b) => a.sort - b.sort)
  .map((a) => a.value)
  .slice(0,noQ);
}

function setQuestion(question){
  gameMain.Test=question['question'];
  gameMain.option1=question['option1'];
  gameMain.option2=question['option2'];
  gameMain.option3=question['option3'];
  gameMain.option4=question['option4'];
  nextBtn.loadNextQ=true;
}

function loadNextQuestion(){
  setQuestion(questionArr[questionArrIndex++]);
}