let gameMain = Vue.createApp({
    data(){
        return{
            Test: 'test',
            option1: 'test',
            option2: 'test',
            option3: 'test',
            option4: 'test',
        }
    }
}).mount('#game-main');

let nextBtn = Vue.createApp({
    data(){
        return{
            loadNextQ: false
        }
    }
}).mount('#nextBtn');
